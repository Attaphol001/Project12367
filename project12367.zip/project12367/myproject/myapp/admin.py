from django.contrib import admin
from .models import Game, Purchase

admin.site.register(Game)
admin.site.register(Purchase)
