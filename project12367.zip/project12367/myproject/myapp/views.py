from django.shortcuts import render, redirect
from .models import Game

# Create your views here.
def home(request):
    return render(request, 'index.html', {
        'image_path': 'images/banner.jpg'
    })

def index(request):
    search_query = request.GET.get('search', '')
    games = Game.objects.all()

    if search_query:
        games = games.filter(name__icontains=search_query)

    return render(request, 'index.html', {'games': games})

def index(request):
    return render(request, 'templates/index.html')

